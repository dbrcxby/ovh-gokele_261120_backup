import type { QueueItem } from "@/hooks/use-queue";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { qk } from "@/lib/query";
import { toast } from "sonner";
import i18n from "@/i18n";
import { apiMessage, bodyMessage } from "@/lib/api-error";

export interface MonitorSubscription {
  duration?: string;
  planCode: string;
  serverName?: string;
  datacenters: string[];
  notifyAvailable: boolean;
  notifyUnavailable: boolean;
  autoOrder?: boolean;
  quantity?: number;
  /** 触发 auto-order 时用哪个 OVH 账户下单;空 = 只通知 */
  autoOrderAccountId?: string;
  /** 下单成功后自动付款(显式开关,默认关) */
  autoPay?: boolean;
  /**
   * 只盯这套配置(addon planCode 列表)。空 / 缺省 = 盯该型号的全部配置。
   *
   * 一个 planCode 底下常有好几套内存/存储组合，而通知和自动下单是**按配置逐套**
   * 触发的 —— 不限定配置时「自动抢 1 台」会变成「每套配置在每个机房各抢 1 台」。
   * 后端引擎一直支持这个字段，只是前端以前没接，所以网页建的订阅永远是「盯全部」。
   */
  options?: string[];
  paused?: boolean;
  lastStatus: Record<string, string>;
  lastRestockAt?: string;
  createdAt: string;
}

export interface MonitorStatus {
  running: boolean;
  subscriptions_count: number;
  check_interval: number;
  known_servers_count: number;
  /** 后端构造的区域问题提示(查错大区导致监控失效等),web 端必须渲染 */
  region_issues?: {
    planCode: string;
    serverName: string;
    accountId: string;
    region: string;
    subsidiary: string;
    checkedAt: string;
    error: string;
  }[];
}

export interface MonitorHistoryEntry {
  timestamp: string;
  datacenter: string;
  status: string;
  changeType: string;
  /** 后端是 interface{}，实际可能是 string / null / 任意 OVH 状态字符串。这里宽松成 unknown */
  oldStatus: unknown;
  config?: {
    memory?: string;
    storage?: string;
    display?: string;
    [key: string]: any;
  };
}

/** 监控订阅列表 */
export function useMonitorList() {
  return useQuery({
    queryKey: qk.monitor.list(),
    // Array.isArray:调用方直接 subs.map,truthy 非数组(响应被代理层改写等)
    // 会让整个监控页白屏 —— 宁可当空列表走"暂无订阅"空态
    queryFn: async () => {
      const d = (await api.get<MonitorSubscription[]>("/monitor/subscriptions")).data;
      return Array.isArray(d) ? d : [];
    },
  });
}

/** 监控引擎运行状态 */
export function useMonitorStatus() {
  return useQuery({
    queryKey: qk.monitor.status(),
    queryFn: async () => (await api.get<MonitorStatus>("/monitor/status")).data,
    refetchInterval: 30_000,
  });
}

/** 某订阅的变化历史（后端直接返回数组，倒序最新在前） */
export function useMonitorHistory(planCode: string | null) {
  return useQuery({
    queryKey: qk.monitor.history(planCode || ""),
    queryFn: async () =>
      (await api.get<MonitorHistoryEntry[]>(`/monitor/subscriptions/${planCode}/history`)).data,
    enabled: !!planCode,
  });
}

/** 新增 / 修改订阅 */
export function useUpsertMonitorSubscription() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: Partial<MonitorSubscription> & { planCode: string }) =>
      (await api.post("/monitor/subscriptions", payload)).data,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.monitor.list() });
      qc.invalidateQueries({ queryKey: qk.monitor.status() });
      toast.success(i18n.t("hooksMsg.monitor.saved"));
    },
    onError: (e: any) => toast.error(apiMessage(e) || i18n.t("hooksMsg.monitor.saveFailed")),
  });
}

/**
 * 修改已有订阅（PUT，只改配置不重置状态）。
 *
 * 为什么不复用上面的 POST：POST 语义上是"新增"，前端也是照着新增的表单发的整包。
 * 而 PUT 只发改动过的字段，后端拿当前值兜底 —— 这样"只改一个数量"不会顺带
 * 把机房列表覆盖成空。两边的状态（LastStatus / History）都不会动，
 * 否则一台本来就有货的机器会在下一轮被当成"补货了"，发一条假通知外加真下单。
 */
export function useUpdateMonitorSubscription() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({
      planCode,
      optionsKey,
      ...patch
    }: Partial<MonitorSubscription> & { planCode: string; optionsKey?: string }) =>
      (await api.put(`/monitor/subscriptions/${encodeURIComponent(planCode)}`, patch, { params: optionsKey === undefined ? undefined : { optionsKey } })).data,
    onSuccess: (data: any) => {
      qc.invalidateQueries({ queryKey: qk.monitor.list() });
      qc.invalidateQueries({ queryKey: qk.monitor.status() });
      if (data?.regionWarning) toast.warning(data.regionWarning);
      else toast.success(bodyMessage(data) || i18n.t("hooksMsg.monitor.updated"));
    },
    onError: (e: any) =>
      toast.error(apiMessage(e) || i18n.t("hooksMsg.monitor.updateFailed")),
  });
}

/** 创建新订阅（对外更语义化的别名） */
export const useCreateMonitorSubscription = useUpsertMonitorSubscription;

/** 暂停订阅及关联队列;恢复监控时不自动恢复队列,但提示条提供一键恢复被它暂停的任务。 */
export function usePauseMonitorSubscription() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (v: { planCode: string; optionsKey?: string; paused: boolean }) =>
      (
        await api.post(`/monitor/subscriptions/${encodeURIComponent(v.planCode)}/pause`, {
          optionsKey: v.optionsKey,
          paused: v.paused,
        })
      ).data,
    onSuccess: (data: { paused?: boolean; pausedTasks?: number; heldTaskIds?: string[] }, vars) => {
      if (data.paused) {
        toast.success(i18n.t("hooksMsg.monitor.pausedWithQueue", { count: data.pausedTasks || 0 }));
        return;
      }
      // 恢复监控不自动恢复抢购任务(避免意外下单),但给一个一键入口:
      // 只列出被「监控暂停」连带暂停的同型号任务(stopReason=monitorPaused),由用户决定
      const queue = qc.getQueryData<QueueItem[]>(qk.queue.list()) || [];
      // 后端按这条订阅的账户/机房/配置范围给出 heldTaskIds,并排除仍被其它暂停订阅覆盖的任务;
      // 旧后端没有该字段时退回按型号筛选
      // 直接用后端给的 ID,不依赖可能尚未刷新的本地队列缓存
      const held: { id: string }[] = data.heldTaskIds
        ? data.heldTaskIds.map((id) => ({ id }))
        : queue.filter((q) => q.status === "paused" && q.stopReason === "monitorPaused" && q.planCode === vars.planCode);
      if (held.length === 0) {
        toast.success(i18n.t("hooksMsg.monitor.resumedNoTasks"));
        return;
      }
      toast.success(i18n.t("hooksMsg.monitor.resumedOnly"), {
        duration: 10000,
        action: {
          label: i18n.t("hooksMsg.monitor.resumeTasks", { count: held.length }),
          onClick: async () => {
            let ok = 0;
            for (const q of held) {
              try {
                await api.put(`/queue/${encodeURIComponent(q.id)}/status`, { status: "running" });
                ok++;
              } catch {
                /* 单条失败不阻断其余;汇总提示 */
              }
            }
            qc.invalidateQueries({ queryKey: qk.queue.list() });
            qc.invalidateQueries({ queryKey: qk.stats() });
            if (ok === held.length) toast.success(i18n.t("hooksMsg.monitor.tasksResumed", { count: ok }));
            else toast.error(i18n.t("hooksMsg.monitor.tasksResumedPartial", { ok, total: held.length }));
          },
        },
      });
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: qk.monitor.list() });
      qc.invalidateQueries({ queryKey: qk.monitor.status() });
      qc.invalidateQueries({ queryKey: qk.queue.list() });
    },
    onError: (e: any) => toast.error(apiMessage(e) || i18n.t("hooksMsg.monitor.updateFailed")),
  });
}

export function useRemoveMonitorSubscription() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (v: { planCode: string; optionsKey?: string }) =>
      (
        await api.delete(`/monitor/subscriptions/${v.planCode}`, {
          params: v.optionsKey ? { optionsKey: v.optionsKey } : undefined,
        })
      ).data,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.monitor.list() });
      qc.invalidateQueries({ queryKey: qk.monitor.status() });
      toast.success(i18n.t("hooksMsg.monitor.deleted"));
    },
    onError: (e: any) => toast.error(apiMessage(e) || i18n.t("hooksMsg.monitor.deleteFailed")),
  });
}

/** 清空所有订阅 */
export function useClearMonitor() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => (await api.delete("/monitor/subscriptions/clear")).data,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.monitor.list() });
      qc.invalidateQueries({ queryKey: qk.monitor.status() });
      toast.success(i18n.t("hooksMsg.monitor.cleared"));
    },
    onError: (e: any) => toast.error(apiMessage(e) || i18n.t("hooksMsg.monitor.clearFailed")),
  });
}

/** 设置检查间隔（秒）。后端会夹到 5-3600，返回真正生效的值。 */
export function useSetMonitorInterval() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (interval: number) =>
      (await api.put("/monitor/interval", { interval })).data as {
        status: string;
        message: string;
        check_interval: number;
      },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: qk.monitor.status() });
      toast.success(bodyMessage(data) || i18n.t("hooksMsg.monitor.intervalUpdated"));
    },
    onError: (e: any) => toast.error(apiMessage(e) || i18n.t("hooksMsg.monitor.intervalSetFailed")),
  });
}

/** 全局启动 / 停止监控。停止会同时暂停所有订阅关联的抢购任务,且重启后不自动恢复。 */
export function useToggleMonitor() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (on: boolean) =>
      (await api.post<{ message?: string; pausedTasks?: number }>(on ? "/monitor/start" : "/monitor/stop")).data,
    onSuccess: (data, on) => {
      toast.success(on ? i18n.t("hooksMsg.monitor.started") : i18n.t("hooksMsg.monitor.stoppedWithQueue", { count: data?.pausedTasks || 0 }));
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: qk.monitor.status() });
      qc.invalidateQueries({ queryKey: qk.queue.list() });
      qc.invalidateQueries({ queryKey: qk.stats() });
    },
    onError: (e: any) => toast.error(apiMessage(e) || i18n.t("hooksMsg.monitor.updateFailed")),
  });
}
