package monitor

import (
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/ovh-buy/server/internal/app"
	"github.com/ovh-buy/server/internal/db"
	"github.com/ovh-buy/server/internal/logger"
	"github.com/ovh-buy/server/internal/types"
)

func renderTestMonitor(t *testing.T) *Monitor {
	t.Helper()
	dir := t.TempDir()
	database, err := db.Open(dir)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	t.Cleanup(func() { database.Close() })
	state := &app.State{
		DB: database,
		Logger: logger.New(filepath.Join(dir, "logs.json"),
			slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelError}))),
	}
	return New(state)
}

// 把用户真正会收到的那条上架通知打印出来。
//
// 通知的排版是这个工具的门面 —— 有货那一刻用户只看得到它，
// 而以前想看一眼长什么样，只能等一次真实补货。
// 跑法：go test ./internal/monitor/ -run TestRenderAvailabilityAlert -v
func TestRenderAvailabilityAlert(t *testing.T) {
	m := renderTestMonitor(t)
	detected := time.Now().Add(-3 * time.Second).Format(time.RFC3339Nano)

	dcs := []map[string]interface{}{
		{"dc": "waw", "detected_time": detected, "raw_status": "1H-low"},
	}
	cfg := map[string]interface{}{
		"display":       "32G + 2x2TB HDD",
		"memory":        "32GB ECC DDR4-2400",
		"storage":       "2x2TB HDD",
		"cached_price":  "€17.99/月",
		"install_price": "€17.99",
		"options":       []string{"ram-32g-ecc-2400", "softraid-2x2000sa"},
	}

	msg, markup := m.buildAvailabilityAlert("24ska01", dcs, cfg, "KS-5",
		"", "trace-9f2a1c", "cfg-77d0")

	fmt.Println("\n┌─────────── Telegram 上架通知 ───────────")
	for _, line := range splitLines(msg) {
		fmt.Println("│ " + line)
	}
	fmt.Println("├─────────── 按钮 ───────────")
	for _, line := range buttonLines(t, markup) {
		fmt.Println("│ " + line)
	}
	fmt.Println("└────────────────────────────")

	// 关键信息必须在,顺带当回归测试
	for _, must := range []string{"KS-5", "32GB ECC DDR4-2400", "2x2TB HDD", "WAW", "1小时内有货 - 低库存", "€17.99"} {
		if !contains(msg, must) {
			t.Errorf("通知里缺少关键信息 %q", must)
		}
	}
}

// 已经有任务在抢同一个型号时，通知里必须提醒 ——
// 补货常连着来好几条通知，对同一台机器按两次就是两笔真实订单。
func TestAlertWarnsAboutExistingQueue(t *testing.T) {
	m := renderTestMonitor(t)
	m.state.QueueMu.Lock()
	m.state.Queue = []types.QueueItem{
		{ID: "q1", PlanCode: "24sk602", Datacenter: "gra", Status: "running"},
		{ID: "q2", PlanCode: "24sk602", Datacenter: "rbx", Status: "pending"},
		{ID: "q3", PlanCode: "24sk602", Datacenter: "sbg", Status: "completed"}, // 已完成不算
		{ID: "q4", PlanCode: "24sk603", Datacenter: "gra", Status: "running"},   // 别的型号不算
	}
	m.state.QueueMu.Unlock()

	dcs := []map[string]interface{}{{"dc": "gra"}}
	msg, _ := m.buildAvailabilityAlert("24sk602", dcs, nil, "KS-LE-B", "", "", "")

	if !contains(msg, "已经有 2 个任务在抢") {
		t.Fatalf("应提醒已有 2 个进行中的任务，实际通知：\n%s", msg)
	}

	fmt.Println("\n┌────── 已在抢时的提醒 ──────")
	for _, line := range splitLines(msg) {
		fmt.Println("│ " + line)
	}
	fmt.Println("└───────────────────────────")
}

// 没有任务在抢时不该凭空冒出这句提醒
func TestAlertNoQueueWarningWhenIdle(t *testing.T) {
	m := renderTestMonitor(t)
	msg, _ := m.buildAvailabilityAlert("24sk602",
		[]map[string]interface{}{{"dc": "gra"}}, nil, "KS-LE-B", "", "", "")
	if contains(msg, "个任务在抢") {
		t.Fatalf("没有进行中的任务时不该有这句提醒：\n%s", msg)
	}
}

func splitLines(s string) []string {
	out := []string{}
	cur := ""
	for _, r := range s {
		if r == '\n' {
			out = append(out, cur)
			cur = ""
			continue
		}
		cur += string(r)
	}
	return append(out, cur)
}

func contains(h, n string) bool {
	return len(n) == 0 || (len(h) >= len(n) && indexOf(h, n) >= 0)
}

func indexOf(h, n string) int {
	for i := 0; i+len(n) <= len(h); i++ {
		if h[i:i+len(n)] == n {
			return i
		}
	}
	return -1
}

// buttonLines 把 inline_keyboard 里每一行按钮渲染成一行文本。
// 键盘里的按钮是函数内的局部类型，直接断言不了，走 JSON 最稳。
func buttonLines(t *testing.T, markup map[string]interface{}) []string {
	t.Helper()
	raw, err := json.Marshal(markup["inline_keyboard"])
	if err != nil {
		t.Fatalf("marshal keyboard: %v", err)
	}
	var rows [][]struct {
		Text         string `json:"text"`
		CallbackData string `json:"callback_data"`
	}
	if err := json.Unmarshal(raw, &rows); err != nil {
		t.Fatalf("unmarshal keyboard: %v", err)
	}
	out := make([]string, 0, len(rows))
	for _, row := range rows {
		line := ""
		for _, b := range row {
			line += "[ " + b.Text + " ]  "
		}
		out = append(out, line)
	}
	return out
}

// 多机房:每个机房的可用性可能不一样(waw 是 1H-low、gra 是 72H)。
// 合并成一句「N 个机房有货」会把这个差别抹掉,而它直接决定先抢哪个。
func TestRenderMultiDCAlert(t *testing.T) {
	m := renderTestMonitor(t)
	detected := time.Now().Add(-2 * time.Second).Format(time.RFC3339Nano)
	dcs := []map[string]interface{}{
		{"dc": "waw", "detected_time": detected, "raw_status": "1H-low"},
		{"dc": "gra", "detected_time": detected, "raw_status": "24H"},
		{"dc": "bhs", "detected_time": detected, "raw_status": "720H"},
	}
	cfg := map[string]interface{}{
		"memory":        "32GB ECC DDR4-2400",
		"storage":       "2x2TB HDD",
		"cached_price":  "€17.99/月",
		"install_price": "€17.99",
	}
	msg, _ := m.buildAvailabilityAlert("24ska01", dcs, cfg, "KS-5", "", "", "")

	fmt.Println("\n┌────── 多机房 ──────")
	for _, line := range splitLines(msg) {
		fmt.Println("│ " + line)
	}
	fmt.Println("└───────────────────")

	// 三个机房各自的可用性都要出现,不能被合并成一句
	for _, must := range []string{"1小时内有货 - 低库存", "24小时内有货", "720小时内有货（约30天）"} {
		if !contains(msg, must) {
			t.Errorf("多机房时每个机房的可用性都要列出来，缺少 %q", must)
		}
	}
	if !contains(msg, "3 个机房有货") {
		t.Error("应当有机房总数")
	}
}

// 价格查不到时必须明说。留空会被读成「免费」或「还没加载」，
// 这两种理解都会让用户按下一个不知道要花多少钱的按钮。
func TestRenderAlertSaysWhenPriceMissing(t *testing.T) {
	m := renderTestMonitor(t)
	dcs := []map[string]interface{}{{"dc": "gra", "raw_status": "24H"}}
	msg, _ := m.buildAvailabilityAlert("24ska01", dcs,
		map[string]interface{}{"memory": "32G", "storage": "2x2TB"},
		"KS-5", "询价超时", "", "")
	if !contains(msg, "未获取到") {
		t.Fatalf("价格缺失必须明说，实际：\n%s", msg)
	}
	if !contains(msg, "询价超时") {
		t.Fatalf("失败原因要带上，实际：\n%s", msg)
	}
}
