package telegram

import (
	"fmt"
	"sort"
	"strings"

	"github.com/google/uuid"

	"github.com/ovh-buy/server/internal/app"
	"github.com/ovh-buy/server/internal/catalog"
	"github.com/ovh-buy/server/internal/orderterm"
	"github.com/ovh-buy/server/internal/ovh"
	"github.com/ovh-buy/server/internal/types"
)

// OrderResult Telegram 下单结果
type OrderResult struct {
	Success       bool   `json:"success"`
	Message       string `json:"message"`
	TotalOrders   int    `json:"total_orders"`
	CreatedOrders int    `json:"created_orders"`
}

// accountRegionLabel 给用户看的账户归属描述:"名字(子公司 US / US 区)"。
// TG 是唯一没有账户选择器的入口,下单落在哪个账户、哪个区,必须在回复里说清楚。
func accountRegionLabel(acc types.OVHAccount) (string, string) {
	sub := strings.ToUpper(strings.TrimSpace(acc.Zone))
	if sub == "" {
		sub = ovh.DefaultSubsidiaryForEndpoint(acc.Endpoint)
	}
	return sub, fmt.Sprintf("%s(子公司 %s / %s 区)", acc.Name, sub, ovh.SubsidiaryRegion(sub))
}

// emptyAvailabilityReason 解释"可用性查不到"到底是哪一种情况。
//
// 为什么需要它:EU / US / CA 三个站点的目录是彼此独立的系统,同一台机器在不同区
// 是不同的 planCode(实测 FR 与 CA 的 eco 目录 planCode 完全一致 99/99,
// 而 US 的 143 个里只有 28 个和 FR 重合;美区机型带 -us 后缀)。
// 拿欧区 planCode 打美区的 /dedicated/server/datacenter/availabilities,
// OVH 返回的是 HTTP 200 + 空数组 —— 不是错误,就是"没有这个机型"。
// 只回一句"无法获取可用性信息"会让用户以为是抢购程序坏了,而真正该做的是换本区的 planCode。
//
// 用目录判断而不是猜后缀:后缀规则是观察出来的,目录才是权威。
// 目录走 catalog 的 2 小时缓存,不额外消耗账户配额。
// 注意 eco 目录只覆盖 Kimsufi/Rise/Advance 这一档,所以"目录里没有"只用来补充说明,
// 不作为拦截条件 —— 否则会误杀不在 eco 目录里但确实能买的机型。
func emptyAvailabilityReason(state *app.State, accountID, planCode string, acc types.OVHAccount) string {
	sub, label := accountRegionLabel(acc)
	base := fmt.Sprintf("无法获取 %s 的可用性信息(本次使用账户 %s)", planCode, label)
	if _, err := catalog.AddonFamiliesForPlan(state, accountID, planCode); err != nil {
		if strings.Contains(err.Error(), "目录里没有 planCode") {
			return base + fmt.Sprintf(
				"\n\n%s 的目录里没有 %s。OVH 的 EU / US / CA 是三套彼此独立的系统,同一台机器在不同区是不同的 planCode"+
					"(美区机型通常带 -us 后缀),用别区的 planCode 查库存 OVH 只会返回空数组而不是报错。"+
					"\n请改用 %s 区的 planCode,或把 /buy 落到对应区的账户上。", sub, planCode, ovh.SubsidiaryRegion(sub))
		}
		// 目录本身没拉到(网络/429):不能据此断言 planCode 不存在,只说明少了一条判据
		return base + fmt.Sprintf("\n\n(顺带一提:%s 的目录本次也没拉到 —— %s,所以无法确认这个 planCode 是不是属于别的区)", sub, err.Error())
	}
	// planCode 在本区目录里确实存在 → 是真的全区无货/已下架,不是区域搞错了
	return base + fmt.Sprintf("\n\n%s 的目录里有 %s,所以不是区域搞错了,而是这个机型当前在所有机房都没有可售配置。", sub, planCode)
}

// accountID 由调用方解析好传进来(按 planCode 反推大区,见 handlers.resolveOrderAccount)。
// 空串 = 退回当前账户 —— 但正常路径不该走到那里:
// 账户选错的后果是"永远抢不到"且 OVH 不报错,必须在下单前就定死。
func ProcessOrder(state *app.State, accountID, planCode, datacenter string, quantity int, options []string, duration string) OrderResult {
	selectedDuration, err := orderterm.Normalize(duration)
	if err != nil {
		return OrderResult{Message: err.Error()}
	}
	if quantity < 1 {
		quantity = 1
	}
	// 用 Telegram 侧当前选中的账户(/accounts 里切),没选过就是默认账户。
	//
	// 必须在这里就解析成具体 ID 并写进队列项:以前 QueueItem.AccountID 留空,
	// 下单时才由 purchase 现取默认账户 —— 中间只要有人改过默认账户(或删掉它),
	// 这一单就会用另一个账户、另一个区的凭据去下,而可用性/目录判断用的
	// 还是此刻这个账户的子公司,两边对不上。
	acc, ok := state.FindAccount(accountID)
	if !ok {
		acc, ok = ActiveAccount(state)
		if !ok && acc.ID == "" {
			return OrderResult{Success: false, Message: "未配置任何 OVH 账户"}
		}
	}
	accountID = acc.ID
	sub, accLabel := accountRegionLabel(acc)

	availByConfig := catalog.CheckServerAvailabilityWithConfigs(state, planCode, accountID)
	if len(availByConfig) == 0 {
		return OrderResult{Success: false, Message: emptyAvailabilityReason(state, accountID, planCode, acc)}
	}

	// 过滤配置
	type configEntry struct {
		key  string
		data *catalog.ConfigAvailability
	}
	configsToOrder := []configEntry{}
	if len(options) > 0 {
		for k, d := range availByConfig {
			// 检查用户 options 是否被该配置完全覆盖
			if subset(options, d.Options) {
				configsToOrder = append(configsToOrder, configEntry{key: k, data: d})
			}
		}
	} else {
		for k, d := range availByConfig {
			configsToOrder = append(configsToOrder, configEntry{key: k, data: d})
		}
	}
	if len(configsToOrder) == 0 {
		return OrderResult{Success: false, Message: fmt.Sprintf("未找到匹配的配置（指定选项: %v）", options)}
	}

	availableDCs := map[string]struct{}{}
	for _, e := range configsToOrder {
		for dc, status := range e.data.Datacenters {
			// comingSoon 也会走到这里,但它下不了单;用白名单避免为永远买不到的机型建单
			if catalog.IsAvailableForOrder(status) {
				availableDCs[dc] = struct{}{}
			}
		}
	}
	if len(availableDCs) == 0 {
		return OrderResult{Success: false, Message: fmt.Sprintf("%s 在账户 %s 可见的所有机房都无货", planCode, accLabel)}
	}
	dcsToOrder := []string{}
	if datacenter != "" {
		// 用户在 TG 里打的是展示名(比如孟买 mum),OVH 可用性/购物车认的是 API 名(ynm)。
		// 不转换的话 availableDCs 里永远查不到 mum,回一句"指定机房无货"——
		// 而 purchase 那边是转换过的,等于同一台机器在两个环节用了两个名字。
		apiDC := ovh.ConvertDisplayDCToAPIDC(datacenter)
		if _, ok := availableDCs[apiDC]; !ok {
			dcs := make([]string, 0, len(availableDCs))
			for dc := range availableDCs {
				dcs = append(dcs, dc)
			}
			sort.Strings(dcs)
			return OrderResult{Success: false, Message: fmt.Sprintf(
				"指定机房 %s 无货(账户 %s 当前有货的机房: %s)",
				strings.ToUpper(datacenter), accLabel, strings.Join(dcs, ", "))}
		}
		dcsToOrder = append(dcsToOrder, apiDC)
	} else {
		for dc := range availableDCs {
			dcsToOrder = append(dcsToOrder, dc)
		}
	}

	totalOrders := len(configsToOrder) * len(dcsToOrder) * quantity
	// 总量封顶。不指定机房时任务数 = 配置数 × 有货机房数 × 数量,
	// 一句 "24ska01 20" 在补货潮里可能扇出上百个任务,每个都会真实下单。
	// 以前完全没有上限,只在回复里提一句"不想跑这么多就去队列删" ——
	// 那时候单已经在下了。
	if totalOrders > MaxOrderFanout {
		state.Logger.Warn(fmt.Sprintf("[Telegram下单] 扇出 %d 超过上限 %d,已拒绝(配置数=%d × 机房数=%d × 数量=%d)",
			totalOrders, MaxOrderFanout, len(configsToOrder), len(dcsToOrder), quantity), "telegram")
		return OrderResult{
			Success:     false,
			TotalOrders: totalOrders,
			Message: fmt.Sprintf("这条指令会创建 %d 个抢购任务(%d 个配置 × %d 个机房 × %d 台),超过单条消息上限 %d。"+
				"请指定机房、减少数量,或到网页端的抢购队列里精确添加",
				totalOrders, len(configsToOrder), len(dcsToOrder), quantity, MaxOrderFanout),
		}
	}
	ordersToCreate := []types.QueueItem{}
	state.Logger.Info(fmt.Sprintf("[Telegram下单] 账户=%s, 子公司=%s, planCode=%s", accLabel, sub, planCode), "telegram")
	for _, ce := range configsToOrder {
		configOptions := append([]string{}, ce.data.Options...)
		state.Logger.Info(fmt.Sprintf("[Telegram下单] 处理配置: memory=%s, storage=%s, options=%v (数量: %d)",
			ce.data.Memory, ce.data.Storage, configOptions, len(configOptions)), "telegram")
		if len(configOptions) == 0 {
			state.Logger.Warn(fmt.Sprintf("[Telegram下单] ⚠️ 配置选项为空！memory=%s, storage=%s",
				ce.data.Memory, ce.data.Storage), "telegram")
		}
		for _, dc := range dcsToOrder {
			if status, ok := ce.data.Datacenters[dc]; ok && !catalog.IsAvailableForOrder(status) {
				continue
			}
			for i := 0; i < quantity; i++ {
				now := types.NowISO()
				item := types.QueueItem{
					ID:            uuid.NewString(),
					AccountID:     accountID,
					PlanCode:      planCode,
					Duration:      selectedDuration,
					Datacenter:    dc,
					Options:       append([]string{}, configOptions...),
					Status:        "running",
					CreatedAt:     now,
					UpdatedAt:     now,
					RetryInterval: state.Config.RetryInterval(),
					RetryCount:    0,
					LastCheckTime: 0,
					FromTelegram:  true,
				}
				ordersToCreate = append(ordersToCreate, item)
				state.Logger.Debug(fmt.Sprintf("[Telegram下单] 创建订单项: planCode=%s, datacenter=%s, options=%v (ID: %s)",
					planCode, dc, item.Options, item.ID[:8]), "telegram")
			}
		}
	}

	// 一次加锁批量入队。
	//
	// 以前这里是"分批 + 每项一个 goroutine",但每个 goroutine 的全部工作就是
	// QueueMu.Lock() → append → Unlock():所有并发路径抢的是同一把锁,实际完全串行,
	// 只是白付了调度和 WaitGroup 的开销。入队是纯内存操作,一次锁全部 append 才是对的。
	created := len(ordersToCreate)
	if created > 0 {
		// 入队 + 落库是一件事:失败时 EnqueueItems 会把这批整体撤回,
		// 不留"这次能跑但重启就丢"的半成功任务 —— 那种状态看起来完全正常
		if err := state.EnqueueItems(ordersToCreate, false); err != nil {
			state.Logger.Error("Telegram 下单后保存队列失败,已撤回: "+err.Error(), "telegram")
			return OrderResult{
				Success:     false,
				TotalOrders: totalOrders,
				Message: fmt.Sprintf("❌ 任务没能写进数据库，已全部撤回（避免出现重启就消失的假任务）：%s",
					err.Error()),
			}
		}
		state.Logger.Info(fmt.Sprintf("已创建 %d/%d 个订单", created, totalOrders), "telegram")
	}
	return OrderResult{
		Success:       true,
		Message:       fmt.Sprintf("已创建 %d/%d 个订单(账户 %s)", created, totalOrders, accLabel),
		TotalOrders:   totalOrders,
		CreatedOrders: created,
	}
}

func subset(needle, haystack []string) bool {
	set := map[string]struct{}{}
	for _, h := range haystack {
		set[h] = struct{}{}
	}
	for _, n := range needle {
		if _, ok := set[n]; !ok {
			return false
		}
	}
	return true
}
